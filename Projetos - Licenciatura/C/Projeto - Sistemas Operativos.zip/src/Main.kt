
fun retirarDeJogo(personagemIdx: Int) {
    if (personagemIdx >= 0 && personagemIdx < personagens.size) {
        personagens[personagemIdx][5] = true
    }
}

fun getNome(personagem: Array<Any?>): String {
    return personagem[0] as String
}

fun getGenero(personagem: Array<Any?>): String {
    return personagem[1] as String
}

fun getCabelo(personagem: Array<Any?>): String {
    return personagem[2] as String
}

fun getCor(personagem: Array<Any?>): String? {
    if (personagem[3] == null) {
        return null
    }
    return personagem[3] as String
}

fun getOlhos(personagem: Array<Any?>): String {
    return personagem[4] as String
}

fun getEliminado(personagem: Array<Any?>): Boolean {
    return personagem[5] as Boolean
}

const val NOME = "nome"
const val COR = "cor"
const val GENERO = "genero"
const val OLHOS = "olhos"
const val CABELO = "cabelo"

val atributosValidos = arrayOf(NOME, COR, GENERO, OLHOS, CABELO)

fun perguntar(pergunta: String, escolhidoIdx: Int): Int {
    val perguntaDividida = pergunta.split(" ")
    if (perguntaDividida.size != 2 || perguntaDividida[1].isEmpty() ||
        perguntaDividida[0] !in atributosValidos) {
        return -1
    }

    var removidos = 0
    for (i in personagens.indices) {
        if (getEliminado(personagens[i])) {
            continue
        }
        val match = when (perguntaDividida[0]) {
            NOME -> getNome(personagens[i]) == perguntaDividida[1]
            GENERO -> getGenero(personagens[i]) == perguntaDividida[1]
            CABELO -> getCabelo(personagens[i]) == perguntaDividida[1]
            COR -> getCor(personagens[i]) == perguntaDividida[1]
            OLHOS -> getOlhos(personagens[i]) == perguntaDividida[1]
            else -> false
        }

        val escolhidoMatch = when (perguntaDividida[0]) {
            NOME -> getNome(personagens[escolhidoIdx - 1]) == perguntaDividida[1]
            GENERO -> getGenero(personagens[escolhidoIdx - 1]) == perguntaDividida[1]
            CABELO -> getCabelo(personagens[escolhidoIdx - 1]) == perguntaDividida[1]
            COR -> getCor(personagens[escolhidoIdx - 1]) == perguntaDividida[1]
            OLHOS -> getOlhos(personagens[escolhidoIdx - 1]) == perguntaDividida[1]
            else -> false
        }

        if (match != escolhidoMatch) {
            retirarDeJogo(i)
            removidos++
        }
    }
    return removidos
}

fun vencedor(): Array<Any?>? {
    var vencedor: Array<Any?>? = null
    for (i in personagens.indices) {
        if (!getEliminado(personagens[i])) {
            if (vencedor != null) {
                return null
            } else {
                vencedor = personagens[i]
            }
        }
    }
    return vencedor
}

fun mostrarPersonagens(): String {
    var tabela = "Personagens em jogo:\n"
    tabela += "# Nome  | Genero    | Cabelo   | Cor      | Olhos    \n"
    var count = 0
    for (i in personagens.indices) {
        if (getEliminado(personagens[i])) {
            continue
        }
        val personagem = personagens[i]
        tabela += "$count ${getNome(personagem)}".padEnd(8)
        tabela += "| ${getGenero(personagem)}".padEnd(12)
        tabela += "| ${getCabelo(personagem)}".padEnd(11)
        tabela += "| "
        if (getCor(personagem) != null) {
            tabela += "${getCor(personagem)}".padEnd(9)
        }else {
            tabela += "-".padEnd(9)
        }
        tabela += "| ${getOlhos(personagem)}".padEnd(11) + "\n"
        count++
    }
    return tabela
}

fun gerarPersonagem(): Int {
    return personagens.indices.random() + 1
}

fun jogo(personagemEscolhido: Int) {
    println("Bem vindo. Eu selecionei uma personagem. Tente adivinhar quem e fazendo perguntas sobre suas caracteristicas.")
    println(obterMenuJogo())
    var input: String
    while (true) {
        println("O que pretende fazer?")
        input = readln().trim()
        when (input) {
            "perguntar" -> {
                println("Identifique o atributo e a sua designacao, por exemplo, \"genero masculino\".")
                val pergunta = readln()
                val nRemovidos = perguntar(pergunta, personagemEscolhido)
                when (nRemovidos) {
                    -1 -> {
                        println("Pergunta invalida.")
                        println(mostrarPersonagens())
                    }
                    else -> {
                        if (nRemovidos == 1) {
                            println("Foi retirada do jogo $nRemovidos personagem.")
                        } else {
                            println("Foram retiradas do jogo $nRemovidos personagens.")
                        }
                        val vencedorP = vencedor()
                        if (vencedorP != null) {
                            println("Parabens! A personagem e o/a ${getNome(vencedorP)}.")
                            lerPersonagens()
                            break
                        }
                        println(mostrarPersonagens())
                    }
                }
            }
            "personagens" -> {
                println(mostrarPersonagens())
            }
            "sair" -> {
                break
            }
            else -> {
                println("Opcao invalida.")
                println(obterMenuJogo())
            }
        }
    }
}

fun lerPersonagens(): Boolean {
    val homem = "masculino"
    val mulher = "feminino"
    val castanho = "castanho"
    val castanhos = "castanhos"
    val liso = "liso"
    val careca = "careca"
    val ondulado = "ondulado"
    val azuis = "azuis"
    val verdes = "verdes"
    personagens = arrayOf(arrayOf("Joao", homem, liso, castanho, castanhos, false),
        arrayOf("Mario", homem, careca, null, azuis, false),
        arrayOf("Sofia", mulher, ondulado, castanho, castanhos, false),
        arrayOf("Joana", mulher, liso, castanho, verdes, false)
    )
    return true
}

var personagens: Array<Array<Any?>> = emptyArray()

fun main() {
    var idxOponente: Int
    var input = ""
    personagens = emptyArray()
    while (input != "exit") {
        println(obterMenu())
        input = readln()
        when (input) {
            "1" -> {
                if (personagens.isEmpty()) {
                    println("Antes de iniciar o jogo tem de ler as personagens.")
                    println("(prima enter para voltar ao menu)")
                    readln()
                } else {
                    idxOponente = gerarPersonagem()
                    jogo(idxOponente)
                }
            }
            "2" -> {
                lerPersonagens()
                println("Personagens lidas com sucesso.")
                println("(prima enter para voltar ao menu)")
                readln()
            }
            "0" -> {
                println("Ate logo!")
                break
            }
            else -> {
                println("Opcao invalida, tente novamente.")
            }
        }
    }
}


fun obterMenu(): String {
    return """
##### QUEM E QUEM!!! #####

Escolha uma opcao:
1 - Jogar
2 - Ler personagens
0 - Sair
"""
}

fun obterMenuJogo(): String {
    return """
Escolha uma opcao:
perguntar   - para perguntar retirando personagens do jogo
personagens - para consultar as personagens em jogo
sair        - para sair do jogo
"""
}
